<footer class="site-footer">
    <div class="container">

        <div class="footer-top">

            <!-- Brand -->
            <div class="footer-brand">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo">
                    <?php echo esc_html( get_bloginfo( 'name' ) ); ?><span>.</span>
                </a>
                <p><?php esc_html_e( 'Professionelles Property Staging in der Schweiz. Wir werten Liegenschaften auf – für mehr Verkaufserlös.', 'stagech' ); ?></p>
            </div>

            <!-- Leistungen -->
            <div class="footer-col">
                <h4><?php esc_html_e( 'Leistungen', 'stagech' ); ?></h4>
                <ul>
                    <li><a href="#"><?php esc_html_e( 'Staging-Paket', 'stagech' ); ?></a></li>
                    <li><a href="#"><?php esc_html_e( 'Renovationen', 'stagech' ); ?></a></li>
                    <li><a href="#"><?php esc_html_e( 'Aussenbereich', 'stagech' ); ?></a></li>
                    <li><a href="#"><?php esc_html_e( 'Beratung', 'stagech' ); ?></a></li>
                    <li><a href="#"><?php esc_html_e( 'Endreinigung', 'stagech' ); ?></a></li>
                </ul>
            </div>

            <!-- Unternehmen -->
            <div class="footer-col">
                <h4><?php esc_html_e( 'Unternehmen', 'stagech' ); ?></h4>
                <ul>
                    <li><a href="#"><?php esc_html_e( 'Über uns', 'stagech' ); ?></a></li>
                    <li><a href="#"><?php esc_html_e( 'Projekte', 'stagech' ); ?></a></li>
                    <li><a href="#"><?php esc_html_e( 'Kundenstimmen', 'stagech' ); ?></a></li>
                    <li><a href="#kontakt"><?php esc_html_e( 'Kontakt', 'stagech' ); ?></a></li>
                </ul>
            </div>

            <!-- Kontakt -->
            <div class="footer-col">
                <h4><?php esc_html_e( 'Kontakt', 'stagech' ); ?></h4>
                <ul>
                    <?php $phone = get_theme_mod( 'contact_phone', '+41 41 000 00 00' ); ?>
                    <?php $email = get_theme_mod( 'contact_email', 'info@stage.ch' ); ?>
                    <?php $addr  = get_theme_mod( 'contact_address', 'Musterstrasse 1, 6000 Luzern' ); ?>
                    <li><a href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></li>
                    <li><a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></li>
                    <li><span><?php echo esc_html( $addr ); ?></span></li>
                </ul>
            </div>

        </div>

        <div class="footer-bottom">
            <p>&copy; <?php echo esc_html( date( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?>. <?php esc_html_e( 'Alle Rechte vorbehalten.', 'stagech' ); ?></p>
            <div style="display:flex;gap:20px;">
                <a href="<?php echo esc_url( get_privacy_policy_url() ); ?>"><?php esc_html_e( 'Datenschutz', 'stagech' ); ?></a>
                <a href="#"><?php esc_html_e( 'Impressum', 'stagech' ); ?></a>
                <a href="#"><?php esc_html_e( 'AGB', 'stagech' ); ?></a>
            </div>
        </div>

    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
