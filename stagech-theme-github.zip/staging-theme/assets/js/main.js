/**
 * Stage.CH – Main JavaScript
 */

(function () {
  'use strict';

  /* ===========================
     HEADER: sticky scroll class
  =========================== */
  const header = document.getElementById('site-header');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 40);
    }, { passive: true });
  }

  /* ===========================
     MOBILE NAV TOGGLE
  =========================== */
  const toggle = document.getElementById('nav-toggle');
  const nav    = document.getElementById('main-nav');

  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));

      const spans = toggle.querySelectorAll('span');
      if (isOpen) {
        spans[0].style.transform = 'translateY(6.5px) rotate(45deg)';
        spans[1].style.opacity   = '0';
        spans[2].style.transform = 'translateY(-6.5px) rotate(-45deg)';
      } else {
        spans[0].style.transform = '';
        spans[1].style.opacity   = '';
        spans[2].style.transform = '';
      }
    });

    document.addEventListener('click', (e) => {
      if (!header.contains(e.target) && nav.classList.contains('open')) {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.querySelectorAll('span').forEach(s => {
          s.style.transform = '';
          s.style.opacity   = '';
        });
      }
    });
  }

  /* ===========================
     SMOOTH SCROLL
  =========================== */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      const offset = header ? header.offsetHeight + 16 : 80;
      window.scrollTo({
        top: target.getBoundingClientRect().top + window.scrollY - offset,
        behavior: 'smooth',
      });
      if (nav && nav.classList.contains('open')) {
        nav.classList.remove('open');
        toggle && toggle.setAttribute('aria-expanded', 'false');
      }
    });
  });

  /* ===========================
     ANIMATE ON SCROLL
  =========================== */
  const animateEls = document.querySelectorAll('[class*="animate-up"]');
  if ('IntersectionObserver' in window && animateEls.length) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.animationPlayState = 'running';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    animateEls.forEach(el => {
      el.style.animationPlayState = 'paused';
      observer.observe(el);
    });
  }

  /* ===========================
     CONTACT FORM AJAX
  =========================== */
  const form      = document.getElementById('contact-form');
  const submitBtn = document.getElementById('cf-submit');
  const statusEl  = document.getElementById('cf-message-status');

  if (form && typeof stagechAjax !== 'undefined') {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name  = form.querySelector('[name="name"]').value.trim();
      const email = form.querySelector('[name="email"]').value.trim();
      if (!name || !email) {
        showStatus('Bitte Name und E-Mail ausfüllen.', 'error');
        return;
      }
      submitBtn.disabled    = true;
      submitBtn.textContent = 'Wird gesendet…';
      const data = new FormData(form);
      data.append('action', 'stagech_contact');
      data.append('nonce',  stagechAjax.nonce);
      try {
        const res  = await fetch(stagechAjax.ajaxurl, { method: 'POST', body: data });
        const json = await res.json();
        if (json.success) {
          showStatus(json.data.message, 'success');
          form.reset();
        } else {
          showStatus(json.data.message || 'Ein Fehler ist aufgetreten.', 'error');
        }
      } catch (err) {
        showStatus('Verbindungsfehler. Bitte direkt per E-Mail kontaktieren.', 'error');
      } finally {
        submitBtn.disabled    = false;
        submitBtn.textContent = 'Anfrage senden';
      }
    });
  }

  function showStatus(msg, type) {
    if (!statusEl) return;
    statusEl.style.display     = 'block';
    statusEl.style.padding     = '12px 16px';
    statusEl.style.borderRadius = '4px';
    statusEl.style.fontSize    = '14px';
    statusEl.style.marginTop   = '8px';
    if (type === 'success') {
      statusEl.style.background = '#E8F5EE';
      statusEl.style.color      = '#2D7A4F';
      statusEl.style.border     = '1px solid #B7DEC8';
    } else {
      statusEl.style.background = '#FDF0EE';
      statusEl.style.color      = '#C0392B';
      statusEl.style.border     = '1px solid #F0C4BC';
    }
    statusEl.textContent = msg;
  }

})();
