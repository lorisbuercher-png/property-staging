<?php
/**
 * Front Page Template
 */
get_header();
?>

<!-- ===========================
     HERO
=========================== -->
<section class="hero" id="hero">
    <div class="container">
        <div class="hero-inner">

            <!-- Left: Content -->
            <div class="hero-content">
                <div class="hero-badge animate-up animate-up--1">
                    <?php echo esc_html( get_theme_mod( 'hero_badge_text', 'Property Staging Schweiz' ) ); ?>
                </div>

                <h1 class="animate-up animate-up--2">
                    <?php echo esc_html( get_theme_mod( 'hero_title_line1', 'Mehr Wert.' ) ); ?><br>
                    <span><?php echo esc_html( get_theme_mod( 'hero_title_line2', 'Mehr Erlös.' ) ); ?></span><br>
                    <?php echo esc_html( get_theme_mod( 'hero_title_line3', 'Gleiche Immobilie.' ) ); ?>
                </h1>

                <p class="hero-lead animate-up animate-up--3">
                    <?php echo esc_html( get_theme_mod( 'hero_lead', 'Wir werten Ihre Liegenschaft professionell auf — von der Rasenpflege bis zur Betonsanierung — damit Sie beim Verkauf maximal profitieren.' ) ); ?>
                </p>

                <div class="hero-buttons animate-up animate-up--3">
                    <a href="<?php echo stagech_get_mod_url( 'hero_btn1_url', '#kontakt' ); ?>" class="btn btn--primary btn--lg">
                        <?php echo stagech_get_mod( 'hero_btn1_text', 'Jetzt Offerte anfragen' ); ?>
                    </a>
                    <a href="<?php echo stagech_get_mod_url( 'hero_btn2_url', '#projekte' ); ?>" class="btn btn--outline btn--lg">
                        <?php echo stagech_get_mod( 'hero_btn2_text', 'Projekte ansehen' ); ?>
                    </a>
                </div>

                <div class="hero-stats">
                    <div class="hero-stat">
                        <div class="hero-stat-num"><?php echo stagech_get_mod( 'hero_stat1_num', '+18%' ); ?></div>
                        <div class="hero-stat-label"><?php echo stagech_get_mod( 'hero_stat1_label', 'Ø Wertsteigerung' ); ?></div>
                    </div>
                    <div class="hero-stat">
                        <div class="hero-stat-num"><?php echo stagech_get_mod( 'hero_stat2_num', '120+' ); ?></div>
                        <div class="hero-stat-label"><?php echo stagech_get_mod( 'hero_stat2_label', 'Objekte aufgewertet' ); ?></div>
                    </div>
                    <div class="hero-stat">
                        <div class="hero-stat-num"><?php echo stagech_get_mod( 'hero_stat3_num', '14 T' ); ?></div>
                        <div class="hero-stat-label"><?php echo stagech_get_mod( 'hero_stat3_label', 'Ø Umsetzungszeit' ); ?></div>
                    </div>
                </div>
            </div>

            <!-- Right: Image -->
            <div class="hero-image">
                <?php $hero_image = get_theme_mod( 'hero_image', '' ); ?>
                <?php if ( $hero_image ) : ?>
                    <img src="<?php echo esc_url( $hero_image ); ?>" alt="<?php esc_attr_e( 'Property Staging', 'stagech' ); ?>">
                <?php else : ?>
                    <div class="hero-image-placeholder">
                        <svg width="64" height="64" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1">
                            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/>
                        </svg>
                        <span><?php esc_html_e( 'Bild im Customizer hochladen', 'stagech' ); ?></span>
                    </div>
                <?php endif; ?>

                <div class="hero-badge-float">
                    <div class="value">+<span>22 000</span></div>
                    <div class="label"><?php esc_html_e( 'CHF mehr Verkaufserlös', 'stagech' ); ?></div>
                </div>
            </div>

        </div>
    </div>
</section>

<!-- ===========================
     TRUST BAR
=========================== -->
<div class="trust-bar">
    <div class="container">
        <div class="trust-bar-inner">
            <span class="trust-label"><?php esc_html_e( 'Vertrauen von:', 'stagech' ); ?></span>
            <div class="trust-items">
                <span class="trust-item">
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                    <?php esc_html_e( 'Treuhänder', 'stagech' ); ?>
                </span>
                <span class="trust-item">
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                    <?php esc_html_e( 'Immobilienmakler', 'stagech' ); ?>
                </span>
                <span class="trust-item">
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/></svg>
                    <?php esc_html_e( 'Privatkunden', 'stagech' ); ?>
                </span>
                <span class="trust-item">
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                    <?php esc_html_e( 'Banken & Investoren', 'stagech' ); ?>
                </span>
            </div>
        </div>
    </div>
</div>

<!-- ===========================
     LEISTUNGEN
=========================== -->
<section class="section section--bg" id="leistungen">
    <div class="container">
        <div class="section-tag"><?php esc_html_e( 'Leistungen', 'stagech' ); ?></div>
        <div class="section-title"><?php esc_html_e( 'Was wir für Sie tun', 'stagech' ); ?></div>
        <div class="section-sub"><?php esc_html_e( 'Alles aus einer Hand — koordiniert, schnell und auf den Verkaufserfolg ausgerichtet.', 'stagech' ); ?></div>

        <div class="services-grid">

            <div class="service-card service-card--featured">
                <div class="service-icon">
                    <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                </div>
                <div class="service-title"><?php esc_html_e( 'Vollständiges Staging-Paket', 'stagech' ); ?></div>
                <div class="service-text"><?php esc_html_e( 'Von der Erstbesichtigung bis zur Verkaufsfreigabe. Wir koordinieren alle Gewerke, planen die Aufwertungsmassnahmen und setzen sie termingerecht um.', 'stagech' ); ?></div>
                <span class="service-tag"><?php esc_html_e( 'Beliebtestes Paket', 'stagech' ); ?></span>
            </div>

            <div class="service-card">
                <div class="service-icon">
                    <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"/></svg>
                </div>
                <div class="service-title"><?php esc_html_e( 'Renovationen & Oberflächen', 'stagech' ); ?></div>
                <div class="service-text"><?php esc_html_e( 'Wände, Böden, Betonoptik — kleine Eingriffe mit grosser Wirkung auf den Ersteindruck.', 'stagech' ); ?></div>
            </div>

            <div class="service-card">
                <div class="service-icon">
                    <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/></svg>
                </div>
                <div class="service-title"><?php esc_html_e( 'Aussenbereich & Garten', 'stagech' ); ?></div>
                <div class="service-text"><?php esc_html_e( 'Rasenmähen, Hecken schneiden, Wege reinigen — der erste Eindruck zählt.', 'stagech' ); ?></div>
            </div>

            <div class="service-card">
                <div class="service-icon">
                    <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"/></svg>
                </div>
                <div class="service-title"><?php esc_html_e( 'Beratung für Treuhänder', 'stagech' ); ?></div>
                <div class="service-text"><?php esc_html_e( 'Wir zeigen, welche Massnahmen den grössten ROI bringen — bevor Sie investieren.', 'stagech' ); ?></div>
            </div>

            <div class="service-card">
                <div class="service-icon">
                    <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/></svg>
                </div>
                <div class="service-title"><?php esc_html_e( 'Reinigung & Entstörung', 'stagech' ); ?></div>
                <div class="service-text"><?php esc_html_e( 'Professionelle Endreinigung, Entrümpelung und Geruchsneutralisation für besichtigungsreife Objekte.', 'stagech' ); ?></div>
            </div>

        </div>
    </div>
</section>

<!-- ===========================
     PROJEKTE / BEFORE-AFTER
=========================== -->
<section class="section section--white" id="projekte">
    <div class="container">
        <div class="section-tag"><?php esc_html_e( 'Projekte', 'stagech' ); ?></div>
        <div class="section-title"><?php esc_html_e( 'Vorher / Nachher', 'stagech' ); ?></div>
        <div class="section-sub"><?php esc_html_e( 'Sehen Sie, was gezielte Aufwertung bewirkt — echte Projekte, echte Resultate.', 'stagech' ); ?></div>

        <?php
        $projekte = new WP_Query([
            'post_type'      => 'projekte',
            'posts_per_page' => 4,
            'post_status'    => 'publish',
        ]);
        ?>

        <div class="ba-grid">
            <?php if ( $projekte->have_posts() ) : ?>
                <?php while ( $projekte->have_posts() ) : $projekte->the_post(); ?>
                    <div class="ba-card">
                        <div class="ba-visual">
                            <?php $before = get_post_meta( get_the_ID(), 'before_image', true ); ?>
                            <?php $after  = get_post_meta( get_the_ID(), 'after_image', true ); ?>
                            <?php if ( has_post_thumbnail() ) : ?>
                                <?php the_post_thumbnail( 'stagech-before-after' ); ?>
                            <?php else : ?>
                                <div class="ba-visual-placeholder ba-visual-placeholder--after"></div>
                            <?php endif; ?>
                            <span class="ba-chip ba-chip--after"><?php esc_html_e( 'Nachher', 'stagech' ); ?></span>
                        </div>
                        <div class="ba-body">
                            <strong><?php the_title(); ?></strong>
                            <p><?php echo wp_trim_words( get_the_excerpt(), 14 ); ?></p>
                            <?php $delta = get_post_meta( get_the_ID(), 'value_increase', true ); ?>
                            <?php if ( $delta ) : ?>
                                <div class="ba-delta">↑ +<?php echo esc_html( $delta ); ?> CHF Verkaufspreis</div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); ?>

            <?php else : ?>
                <!-- Platzhalter-Karten wenn noch keine Projekte erfasst sind -->
                <?php
                $placeholders = [
                    [ 'Terrasse aufgewertet',   'Beton saniert, Grünfläche gepflegt',       '22 000', 'after'  ],
                    [ 'Eingang renoviert',        'Frisch gestrichen, Fassade gereinigt',     '15 000', 'after'  ],
                    [ 'Wohnzimmer Staging',       'Neuer Boden, Wandfarbe, Beleuchtung',      '31 000', 'after'  ],
                    [ 'Garten & Aussenanlage',    'Rasen, Hecke, Wegplatten neu gesetzt',     '18 000', 'after'  ],
                ];
                foreach ( $placeholders as $ph ) : ?>
                <div class="ba-card">
                    <div class="ba-visual">
                        <div class="ba-visual-placeholder ba-visual-placeholder--<?php echo esc_attr( $ph[3] ); ?>"></div>
                        <span class="ba-chip ba-chip--<?php echo esc_attr( $ph[3] ); ?>"><?php echo $ph[3] === 'after' ? esc_html__( 'Nachher', 'stagech' ) : esc_html__( 'Vorher', 'stagech' ); ?></span>
                    </div>
                    <div class="ba-body">
                        <strong><?php echo esc_html( $ph[0] ); ?></strong>
                        <p><?php echo esc_html( $ph[1] ); ?></p>
                        <div class="ba-delta">↑ +<?php echo esc_html( $ph[2] ); ?> CHF Verkaufspreis</div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- ===========================
     ABLAUF
=========================== -->
<section class="section section--bg" id="ablauf">
    <div class="container container--narrow">
        <div class="section-tag"><?php esc_html_e( 'Ablauf', 'stagech' ); ?></div>
        <div class="section-title"><?php esc_html_e( 'So einfach geht's', 'stagech' ); ?></div>
        <div class="section-sub"><?php esc_html_e( 'Unkompliziert, transparent, termingerecht — für Treuhänder und Privatkunden.', 'stagech' ); ?></div>

        <div class="steps">
            <?php
            $steps = [
                [ '01', __( 'Kostenloses Erstgespräch', 'stagech' ),        __( 'Wir besichtigen das Objekt und analysieren gemeinsam das Aufwertungspotenzial — ohne Risiko für Sie.', 'stagech' ) ],
                [ '02', __( 'Massnahmenplan & Offerte', 'stagech' ),        __( 'Sie erhalten eine klare Übersicht: Was kostet wie viel, was bringt wie viel — transparent und nachvollziehbar.', 'stagech' ) ],
                [ '03', __( 'Umsetzung in 14 Tagen', 'stagech' ),           __( 'Unser Team koordiniert alle Arbeiten termingerecht. Sie müssen sich um nichts kümmern.', 'stagech' ) ],
                [ '04', __( 'Verkaufsbereit & dokumentiert', 'stagech' ),   __( 'Fotodokumentation aller Massnahmen für Ihr Marketing — fertig für die Ausschreibung.', 'stagech' ) ],
            ];
            foreach ( $steps as $step ) : ?>
            <div class="step">
                <div class="step-num"><?php echo esc_html( $step[0] ); ?></div>
                <div class="step-content">
                    <strong><?php echo esc_html( $step[1] ); ?></strong>
                    <p><?php echo esc_html( $step[2] ); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ===========================
     TESTIMONIALS
=========================== -->
<section class="section section--dark">
    <div class="container">
        <div class="section-tag"><?php esc_html_e( 'Kundenstimmen', 'stagech' ); ?></div>
        <div class="section-title section-title--light"><?php esc_html_e( 'Was unsere Kunden sagen', 'stagech' ); ?></div>
        <div class="section-sub section-sub--light"><?php esc_html_e( 'Treuhänder und Immobilienbesitzer aus der ganzen Schweiz vertrauen uns.', 'stagech' ); ?></div>

        <div class="rating-summary">
            <div class="rating-big">4.9</div>
            <div class="rating-meta">
                <div class="stars">★★★★★</div>
                <div class="count"><?php esc_html_e( 'aus 48 Bewertungen', 'stagech' ); ?></div>
            </div>
        </div>

        <div class="testimonials-grid">
            <?php
            $testimonials = new WP_Query([
                'post_type'      => 'testimonials',
                'posts_per_page' => 3,
                'post_status'    => 'publish',
            ]);
            ?>
            <?php if ( $testimonials->have_posts() ) : ?>
                <?php while ( $testimonials->have_posts() ) : $testimonials->the_post(); ?>
                    <?php
                    $initials = strtoupper( substr( get_the_title(), 0, 1 ) . ( strpos( get_the_title(), ' ' ) !== false ? substr( get_the_title(), strpos( get_the_title(), ' ' ) + 1, 1 ) : '' ) );
                    $role     = get_post_meta( get_the_ID(), 'reviewer_role', true );
                    ?>
                    <div class="review-card">
                        <div class="review-stars">★★★★★</div>
                        <div class="review-text"><?php echo wp_kses_post( get_the_content() ); ?></div>
                        <div class="reviewer">
                            <div class="reviewer-avatar"><?php echo esc_html( $initials ); ?></div>
                            <div>
                                <div class="reviewer-name"><?php the_title(); ?></div>
                                <?php if ( $role ) : ?>
                                    <div class="reviewer-role"><?php echo esc_html( $role ); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); ?>

            <?php else : ?>
                <!-- Platzhalter-Bewertungen -->
                <?php
                $reviews = [
                    [ 'MH', 'Markus Huber',    'Treuhänder, Zürich',        'Wir haben mehrere Liegenschaften über Stage.CH aufgewertet. Das Ergebnis: schnellere Verkäufe und deutlich höhere Abschlusspreise. Sehr empfehlenswert!' ],
                    [ 'SK', 'Sandra Kessler',  'Immobilienmaklerin, Luzern', 'Professionell, schnell und zuverlässig. Die Zusammenarbeit war unkompliziert und das Ergebnis hat unsere Erwartungen übertroffen.' ],
                    [ 'TP', 'Thomas Pfister',  'Privatkunde, Zug',           'Dank Stage.CH konnten wir unsere Wohnung CHF 35 000 über dem Schätzwert verkaufen. Investition von CHF 4 500 — Rendite unschlagbar.' ],
                ];
                foreach ( $reviews as $r ) : ?>
                <div class="review-card">
                    <div class="review-stars">★★★★★</div>
                    <div class="review-text"><?php echo esc_html( $r[3] ); ?></div>
                    <div class="reviewer">
                        <div class="reviewer-avatar"><?php echo esc_html( $r[0] ); ?></div>
                        <div>
                            <div class="reviewer-name"><?php echo esc_html( $r[1] ); ?></div>
                            <div class="reviewer-role"><?php echo esc_html( $r[2] ); ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- ===========================
     KONTAKT
=========================== -->
<section class="section section--bg" id="kontakt">
    <div class="container">
        <div class="contact-grid">

            <!-- Form -->
            <div>
                <div class="section-tag"><?php esc_html_e( 'Kontakt', 'stagech' ); ?></div>
                <div class="section-title"><?php esc_html_e( 'Offerte anfragen', 'stagech' ); ?></div>
                <p style="color:var(--muted);font-weight:300;margin-bottom:32px;"><?php esc_html_e( 'Kostenlose Erstberatung. Keine Verpflichtung. Antwort innert 24h.', 'stagech' ); ?></p>

                <form class="contact-form" id="contact-form" novalidate>
                    <?php wp_nonce_field( 'stagech_contact_nonce', '_wpnonce' ); ?>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                        <div class="form-group">
                            <label for="cf-name"><?php esc_html_e( 'Name *', 'stagech' ); ?></label>
                            <input type="text" id="cf-name" name="name" required placeholder="<?php esc_attr_e( 'Max Muster', 'stagech' ); ?>">
                        </div>
                        <div class="form-group">
                            <label for="cf-email"><?php esc_html_e( 'E-Mail *', 'stagech' ); ?></label>
                            <input type="email" id="cf-email" name="email" required placeholder="<?php esc_attr_e( 'max@muster.ch', 'stagech' ); ?>">
                        </div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                        <div class="form-group">
                            <label for="cf-phone"><?php esc_html_e( 'Telefon', 'stagech' ); ?></label>
                            <input type="tel" id="cf-phone" name="phone" placeholder="<?php esc_attr_e( '+41 79 000 00 00', 'stagech' ); ?>">
                        </div>
                        <div class="form-group">
                            <label for="cf-type"><?php esc_html_e( 'Objekttyp', 'stagech' ); ?></label>
                            <select id="cf-type" name="object_type">
                                <option value=""><?php esc_html_e( 'Bitte wählen', 'stagech' ); ?></option>
                                <option value="Eigentumswohnung"><?php esc_html_e( 'Eigentumswohnung', 'stagech' ); ?></option>
                                <option value="Einfamilienhaus"><?php esc_html_e( 'Einfamilienhaus', 'stagech' ); ?></option>
                                <option value="Mehrfamilienhaus"><?php esc_html_e( 'Mehrfamilienhaus', 'stagech' ); ?></option>
                                <option value="Gewerbe"><?php esc_html_e( 'Gewerbeliegenschaft', 'stagech' ); ?></option>
                                <option value="Sonstiges"><?php esc_html_e( 'Sonstiges', 'stagech' ); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="cf-message"><?php esc_html_e( 'Ihre Nachricht', 'stagech' ); ?></label>
                        <textarea id="cf-message" name="message" placeholder="<?php esc_attr_e( 'Beschreiben Sie kurz Ihr Objekt und Ihre Wünsche…', 'stagech' ); ?>"></textarea>
                    </div>
                    <div>
                        <button type="submit" class="btn btn--gold btn--lg" id="cf-submit">
                            <?php esc_html_e( 'Anfrage senden', 'stagech' ); ?>
                        </button>
                    </div>
                    <div id="cf-message-status" style="display:none;"></div>
                    <p class="form-note"><?php echo esc_html( get_theme_mod( 'contact_note', 'Kostenlose Erstberatung · Keine Verpflichtung · Antwort innert 24h' ) ); ?></p>
                </form>
            </div>

            <!-- Contact info -->
            <div class="contact-info">
                <h3><?php esc_html_e( 'Ihr Objekt hat Potenzial.', 'stagech' ); ?></h3>
                <p><?php esc_html_e( 'Lassen Sie uns gemeinsam herausfinden, wie viel mehr Sie herausholen können. Wir melden uns innerhalb eines Werktages.', 'stagech' ); ?></p>

                <div class="contact-item">
                    <div class="contact-item-icon">
                        <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                    </div>
                    <div>
                        <strong><?php esc_html_e( 'Telefon', 'stagech' ); ?></strong>
                        <span><?php echo esc_html( get_theme_mod( 'contact_phone', '+41 41 000 00 00' ) ); ?></span>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-item-icon">
                        <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                    </div>
                    <div>
                        <strong><?php esc_html_e( 'E-Mail', 'stagech' ); ?></strong>
                        <span><?php echo esc_html( get_theme_mod( 'contact_email', 'info@stage.ch' ) ); ?></span>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-item-icon">
                        <svg width="18" height="18" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    </div>
                    <div>
                        <strong><?php esc_html_e( 'Adresse', 'stagech' ); ?></strong>
                        <span><?php echo esc_html( get_theme_mod( 'contact_address', 'Musterstrasse 1, 6000 Luzern' ) ); ?></span>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<?php get_footer(); ?>
