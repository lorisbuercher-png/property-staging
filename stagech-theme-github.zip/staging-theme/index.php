<?php
/**
 * Fallback index template
 */
get_header();
?>

<main id="main-content">
    <div class="container section">
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h1><?php the_title(); ?></h1>
                    <div><?php the_content(); ?></div>
                </article>
            <?php endwhile; ?>
        <?php else : ?>
            <p><?php esc_html_e( 'Kein Inhalt gefunden.', 'stagech' ); ?></p>
        <?php endif; ?>
    </div>
</main>

<?php get_footer(); ?>
