<?php
/**
 * Stage.CH Theme Functions
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'STAGECH_VERSION', '1.0.0' );
define( 'STAGECH_DIR', get_template_directory() );
define( 'STAGECH_URI', get_template_directory_uri() );

/* ===========================
   THEME SETUP
=========================== */
function stagech_setup() {
    load_theme_textdomain( 'stagech', STAGECH_DIR . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ] );
    add_theme_support( 'custom-logo', [
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ]);
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'wp-block-styles' );

    // Image sizes
    add_image_size( 'stagech-hero',      1400, 800,  true );
    add_image_size( 'stagech-card',      800,  600,  true );
    add_image_size( 'stagech-before-after', 720, 480, true );

    // Navigation menus
    register_nav_menus([
        'primary' => __( 'Hauptnavigation', 'stagech' ),
        'footer'  => __( 'Footer Navigation', 'stagech' ),
    ]);
}
add_action( 'after_setup_theme', 'stagech_setup' );

/* ===========================
   ENQUEUE SCRIPTS & STYLES
=========================== */
function stagech_assets() {
    // Google Fonts
    wp_enqueue_style(
        'stagech-fonts',
        'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=DM+Sans:wght@300;400;500&display=swap',
        [],
        null
    );

    // Main stylesheet
    wp_enqueue_style(
        'stagech-style',
        get_stylesheet_uri(),
        [ 'stagech-fonts' ],
        STAGECH_VERSION
    );

    // Main JS
    wp_enqueue_script(
        'stagech-main',
        STAGECH_URI . '/assets/js/main.js',
        [],
        STAGECH_VERSION,
        true
    );

    // Contact form nonce
    if ( is_page_template( 'page-contact.php' ) || is_front_page() ) {
        wp_localize_script( 'stagech-main', 'stagechAjax', [
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'stagech_contact_nonce' ),
        ]);
    }
}
add_action( 'wp_enqueue_scripts', 'stagech_assets' );

/* ===========================
   CUSTOM POST TYPE: PROJEKTE
=========================== */
function stagech_register_post_types() {
    register_post_type( 'projekte', [
        'labels' => [
            'name'          => __( 'Projekte', 'stagech' ),
            'singular_name' => __( 'Projekt', 'stagech' ),
            'add_new_item'  => __( 'Neues Projekt', 'stagech' ),
            'edit_item'     => __( 'Projekt bearbeiten', 'stagech' ),
        ],
        'public'        => true,
        'has_archive'   => true,
        'rewrite'       => [ 'slug' => 'projekte' ],
        'supports'      => [ 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ],
        'menu_icon'     => 'dashicons-building',
        'show_in_rest'  => true,
    ]);

    register_post_type( 'testimonials', [
        'labels' => [
            'name'          => __( 'Kundenstimmen', 'stagech' ),
            'singular_name' => __( 'Kundenstimme', 'stagech' ),
            'add_new_item'  => __( 'Neue Kundenstimme', 'stagech' ),
        ],
        'public'       => false,
        'show_ui'      => true,
        'show_in_menu' => true,
        'supports'     => [ 'title', 'editor', 'custom-fields' ],
        'menu_icon'    => 'dashicons-format-quote',
    ]);
}
add_action( 'init', 'stagech_register_post_types' );

/* ===========================
   CUSTOM TAXONOMY: LEISTUNGEN
=========================== */
function stagech_register_taxonomies() {
    register_taxonomy( 'leistungsart', 'projekte', [
        'labels' => [
            'name'          => __( 'Leistungsart', 'stagech' ),
            'singular_name' => __( 'Leistungsart', 'stagech' ),
        ],
        'hierarchical'  => true,
        'public'        => true,
        'rewrite'       => [ 'slug' => 'leistungsart' ],
        'show_in_rest'  => true,
    ]);
}
add_action( 'init', 'stagech_register_taxonomies' );

/* ===========================
   THEME OPTIONS (CUSTOMIZER)
=========================== */
function stagech_customizer( $wp_customize ) {
    // Panel
    $wp_customize->add_panel( 'stagech_panel', [
        'title'    => __( 'Stage.CH Einstellungen', 'stagech' ),
        'priority' => 160,
    ]);

    // -- Hero Section --
    $wp_customize->add_section( 'stagech_hero', [
        'title' => __( 'Hero-Bereich', 'stagech' ),
        'panel' => 'stagech_panel',
    ]);
    stagech_add_setting( $wp_customize, 'hero_badge_text',      'stagech_hero', 'text',  'Property Staging Schweiz' );
    stagech_add_setting( $wp_customize, 'hero_title_line1',     'stagech_hero', 'text',  'Mehr Wert.' );
    stagech_add_setting( $wp_customize, 'hero_title_line2',     'stagech_hero', 'text',  'Mehr Erlös.' );
    stagech_add_setting( $wp_customize, 'hero_title_line3',     'stagech_hero', 'text',  'Gleiche Immobilie.' );
    stagech_add_setting( $wp_customize, 'hero_lead',            'stagech_hero', 'textarea', 'Wir werten Ihre Liegenschaft professionell auf — von der Rasenpflege bis zur Betonsanierung — damit Sie beim Verkauf maximal profitieren.' );
    stagech_add_setting( $wp_customize, 'hero_btn1_text',       'stagech_hero', 'text',  'Jetzt Offerte anfragen' );
    stagech_add_setting( $wp_customize, 'hero_btn1_url',        'stagech_hero', 'url',   '#kontakt' );
    stagech_add_setting( $wp_customize, 'hero_btn2_text',       'stagech_hero', 'text',  'Projekte ansehen' );
    stagech_add_setting( $wp_customize, 'hero_btn2_url',        'stagech_hero', 'url',   '#projekte' );
    stagech_add_setting( $wp_customize, 'hero_stat1_num',       'stagech_hero', 'text',  '+18%' );
    stagech_add_setting( $wp_customize, 'hero_stat1_label',     'stagech_hero', 'text',  'Ø Wertsteigerung' );
    stagech_add_setting( $wp_customize, 'hero_stat2_num',       'stagech_hero', 'text',  '120+' );
    stagech_add_setting( $wp_customize, 'hero_stat2_label',     'stagech_hero', 'text',  'Objekte aufgewertet' );
    stagech_add_setting( $wp_customize, 'hero_stat3_num',       'stagech_hero', 'text',  '14 T' );
    stagech_add_setting( $wp_customize, 'hero_stat3_label',     'stagech_hero', 'text',  'Ø Umsetzungszeit' );
    stagech_add_setting( $wp_customize, 'hero_image',           'stagech_hero', 'image', '' );

    // -- Kontakt --
    $wp_customize->add_section( 'stagech_contact', [
        'title' => __( 'Kontakt', 'stagech' ),
        'panel' => 'stagech_panel',
    ]);
    stagech_add_setting( $wp_customize, 'contact_email',   'stagech_contact', 'email', 'info@stage.ch' );
    stagech_add_setting( $wp_customize, 'contact_phone',   'stagech_contact', 'text',  '+41 41 000 00 00' );
    stagech_add_setting( $wp_customize, 'contact_address', 'stagech_contact', 'text',  'Musterstrasse 1, 6000 Luzern' );
    stagech_add_setting( $wp_customize, 'contact_note',    'stagech_contact', 'text',  'Kostenlose Erstberatung · Antwort innert 24h' );
}
add_action( 'customize_register', 'stagech_customizer' );

/** Helper: add setting + control */
function stagech_add_setting( $wp_customize, $id, $section, $type, $default ) {
    $wp_customize->add_setting( $id, [
        'default'           => $default,
        'sanitize_callback' => $type === 'textarea' ? 'sanitize_textarea_field' : ( $type === 'url' ? 'esc_url_raw' : 'sanitize_text_field' ),
        'transport'         => 'refresh',
    ]);
    $control_args = [
        'section' => $section,
        'label'   => ucwords( str_replace( '_', ' ', $id ) ),
        'type'    => in_array( $type, [ 'text', 'email', 'url', 'textarea' ] ) ? ( $type === 'textarea' ? 'textarea' : 'text' ) : 'text',
    ];
    if ( $type === 'image' ) {
        $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, $id, array_merge( $control_args, [ 'section' => $section ] ) ) );
    } else {
        $wp_customize->add_control( $id, $control_args );
    }
}

/* ===========================
   AJAX CONTACT FORM
=========================== */
function stagech_handle_contact() {
    check_ajax_referer( 'stagech_contact_nonce', 'nonce' );

    $name    = sanitize_text_field( $_POST['name'] ?? '' );
    $email   = sanitize_email( $_POST['email'] ?? '' );
    $phone   = sanitize_text_field( $_POST['phone'] ?? '' );
    $object  = sanitize_text_field( $_POST['object_type'] ?? '' );
    $message = sanitize_textarea_field( $_POST['message'] ?? '' );

    if ( empty( $name ) || empty( $email ) || ! is_email( $email ) ) {
        wp_send_json_error( [ 'message' => 'Bitte Name und gültige E-Mail angeben.' ] );
    }

    $to      = get_theme_mod( 'contact_email', get_option( 'admin_email' ) );
    $subject = "Neue Anfrage von {$name} – Stage.CH";
    $body    = "Name: {$name}\nE-Mail: {$email}\nTelefon: {$phone}\nObjekttyp: {$object}\n\nNachricht:\n{$message}";
    $headers = [ 'Content-Type: text/plain; charset=UTF-8', "Reply-To: {$email}" ];

    $sent = wp_mail( $to, $subject, $body, $headers );
    if ( $sent ) {
        wp_send_json_success( [ 'message' => 'Vielen Dank! Wir melden uns innert 24 Stunden.' ] );
    } else {
        wp_send_json_error( [ 'message' => 'Fehler beim Senden. Bitte kontaktieren Sie uns direkt per E-Mail.' ] );
    }
}
add_action( 'wp_ajax_stagech_contact',        'stagech_handle_contact' );
add_action( 'wp_ajax_nopriv_stagech_contact', 'stagech_handle_contact' );

/* ===========================
   WIDGETS
=========================== */
function stagech_widgets_init() {
    register_sidebar([
        'name'          => __( 'Footer Widget-Bereich', 'stagech' ),
        'id'            => 'footer-widget',
        'before_widget' => '<div class="footer-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ]);
}
add_action( 'widgets_init', 'stagech_widgets_init' );

/* ===========================
   HELPER FUNCTIONS
=========================== */
function stagech_get_mod( $key, $default = '' ) {
    return esc_html( get_theme_mod( $key, $default ) );
}

function stagech_get_mod_url( $key, $default = '#' ) {
    return esc_url( get_theme_mod( $key, $default ) );
}
