# Stage.CH – WordPress Theme

Premium WordPress Theme für **Property Staging** — ohne Page Builder, reines PHP/CSS/JS.

---

## Features

- Kein Elementor, kein Page Builder nötig
- Vollständig responsive (Mobile, Tablet, Desktop)
- Custom Post Types: **Projekte** & **Kundenstimmen**
- Alle Texte editierbar via WordPress **Customizer**
- AJAX-Kontaktformular mit Nonce-Schutz
- Smooth Scroll, Mobile-Nav, Animate-on-Scroll
- Google Fonts: Playfair Display + DM Sans

---

## Dateistruktur

```
staging-theme/
├── style.css              # Theme-Metadaten + komplettes CSS
├── functions.php          # Theme-Setup, CPTs, Customizer, AJAX
├── header.php             # Header & Navigation
├── footer.php             # Footer
├── front-page.php         # Startseite (Landingpage)
├── index.php              # Fallback-Template
├── assets/
│   └── js/
│       └── main.js        # Navigation, Scroll, Formular
└── README.md
```

---

## Installation

### Option A – ZIP hochladen
1. Repository als ZIP herunterladen (`Code → Download ZIP`)
2. WP-Admin → **Design → Themes → Installieren → Theme hochladen**
3. ZIP auswählen → Installieren → Aktivieren

### Option B – FTP
1. Ordner `staging-theme` nach `/wp-content/themes/` hochladen
2. WP-Admin → **Design → Themes** → aktivieren

---

## Einrichtung

### Startseite festlegen
`Einstellungen → Lesen → Statische Seite` → neue Seite „Startseite" erstellen → auswählen.

### Navigation
`Design → Menüs` → Neues Menü → Position „Hauptnavigation".

Empfohlene Ankerpunkte:
- `#leistungen`
- `#projekte`
- `#ablauf`
- `#kontakt`

### Texte & Bilder
`Design → Customizer → Stage.CH Einstellungen`

### Projekte erfassen
`Projekte → Neu hinzufügen` — Custom Fields:

| Key | Beschreibung |
|---|---|
| `value_increase` | Wertsteigerung CHF z.B. `22 000` |
| `before_image` | URL Vorher-Bild |
| `after_image` | URL Nachher-Bild |

### Kundenstimmen erfassen
`Kundenstimmen → Neu` — Titel = Name, Inhalt = Text, Custom Field `reviewer_role` = Funktion.

---

## Farben anpassen

In `style.css` die CSS-Variablen oben:

```css
:root {
  --gold: #B8965A;
  --dark: #1A1814;
  --bg:   #F7F5F0;
}
```

---

## Empfohlene Plugins

| Plugin | Zweck |
|---|---|
| Advanced Custom Fields | Custom Fields für Projekte |
| Yoast SEO | SEO |
| WP Mail SMTP | Zuverlässiger Mailversand |
| Wordfence | Sicherheit |

---

## Lizenz
GNU General Public License v2 or later.
