<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header" id="site-header">
    <div class="container">
        <div class="header-inner">

            <!-- Logo -->
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo">
                <?php if ( has_custom_logo() ) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <?php echo esc_html( get_bloginfo( 'name' ) ); ?><span>.</span>
                <?php endif; ?>
            </a>

            <!-- Navigation -->
            <nav class="main-nav" id="main-nav" aria-label="<?php esc_attr_e( 'Hauptnavigation', 'stagech' ); ?>">
                <?php
                wp_nav_menu([
                    'theme_location' => 'primary',
                    'container'      => false,
                    'fallback_cb'    => function() {
                        echo '<ul>';
                        echo '<li><a href="#leistungen">' . __( 'Leistungen', 'stagech' ) . '</a></li>';
                        echo '<li><a href="#projekte">' . __( 'Projekte', 'stagech' ) . '</a></li>';
                        echo '<li><a href="#ablauf">' . __( 'Ablauf', 'stagech' ) . '</a></li>';
                        echo '<li><a href="#kontakt">' . __( 'Kontakt', 'stagech' ) . '</a></li>';
                        echo '</ul>';
                    },
                ]);
                ?>
            </nav>

            <!-- CTA -->
            <a href="#kontakt" class="btn btn--primary header-cta">
                <?php esc_html_e( 'Offerte anfragen', 'stagech' ); ?>
            </a>

            <!-- Mobile toggle -->
            <button class="nav-toggle" id="nav-toggle" aria-label="<?php esc_attr_e( 'Menü öffnen', 'stagech' ); ?>" aria-expanded="false" aria-controls="main-nav">
                <span></span>
                <span></span>
                <span></span>
            </button>

        </div>
    </div>
</header>
